-- Full-board rollback through the native save/load path. Lua 5.1.
local mod = {
    id = "ITB_TurnRollback_Lua",
    name = "Turn Rollback - prev / restart",
    version = "1.1.0",
    modApiVersion = "2.9.6",
    requirements = {},
}
local enabled = false
local native
local sequence = os.time() % 0x7fffffff
local function log(message) LOG("[TurnRollback] " .. tostring(message)) end
local function mission()
    if not Game or not Board or not GAME then return nil end
    if IsTestMechScenario() then return nil end
    return GetCurrentMission()
end
local function nextName()
    repeat
        sequence = (sequence + 1) % 0x7fffffff
        local name = string.format("tr%08x.lua", sequence)
        local path = GetSavedataLocation() .. "profile_" .. Settings.last_profile .. "/" .. name
        if not modApi:fileExists(path) then return name end
    until false
end
local function currentHistory()
    local m = mission()
    if not m or not GAME.ITBTR or GAME.ITBTR.battle ~= m.ITBTR_battle then return nil end
    return GAME.ITBTR
end
local function cleanupSnapshots()
    -- Only direct children of the ACTIVE profile can be considered. Verify both
    -- the generated filename and our serialized history before deleting a file.
    local directory = Directory.savedata():directory("profile_" .. Settings.last_profile)
    local removed, failed = 0, 0
    for _, file in ipairs(directory:files()) do
        local name = file:name()
        if name:match("^tr%x%x%x%x%x%x%x%x%.lua$") then
            local ok, why = pcall(function()
                local text = file:read_to_string()
                local history = text:match('%["ITBTR"%]%s*=%s*{')
                -- The mission tag also identifies snapshots written by v1.0.
                local tag = text:match('%["ITBTR_battle"%]%s*=%s*"tr%x%x%x%x%x%x%x%x%.lua"')
                local owner = text:match('%["owner"%]%s*=%s*"ITB_TurnRollback_Lua"')
                if not history or not (tag or owner) then return end
                -- Remove the engine cache entry as well as the physical file,
                -- so a delayed cache flush cannot bring old snapshots back.
                assert(native.deleteSnapshot(file:path()), "native cleanup refused")
                if file:exists() then file:delete() end
                assert(not file:exists(), "snapshot still exists")
                removed = removed + 1
            end)
            if not ok then
                failed = failed + 1
                log("Could not clean snapshot " .. name .. ": " .. tostring(why))
            end
        end
    end
    log("Old snapshots cleaned: " .. removed .. "; failed: " .. failed)
end
function ITBTR_chooseSnapshot(source)
    if not enabled or not mission() then return nil end
    local history = currentHistory()
    if not history then return nil end
    local turn = Game:GetTurnCount()
    local key = tostring(turn)
    local isTurn = source == "undoSave.lua" and Game:GetTeamTurn() == TEAM_PLAYER
    local isStart = source == "saveData.lua" and history.pendingStart
    if not isStart and not (isTurn and not history.turns[key]) then return nil end
    local name = nextName()
    if isStart or not history.start then
        history.start = name
        history.pendingStart = nil
    end
    if isTurn then history.turns[key] = name end
    log("snapshot " .. name .. " / " .. source .. " / player turn " .. turn)
    return name
end
function ITBTR_prepare(command)
    if not enabled then return nil end
    local history = currentHistory()
    if not history then
        log("No history for this battle. Start a NEW battle with this mod enabled.")
        return nil
    end
    if Game:GetTeamTurn() ~= TEAM_PLAYER or Board:GetBusyState() ~= 0 then
        log("Wait until your turn and all animations have finished.")
        return nil
    end
    local target, targetTurn
    if command == "restart" then
        target = history.start
    elseif command == "prev" then
        local now = Game:GetTurnCount()
        for turn, name in pairs(history.turns) do
            turn = tonumber(turn)
            if turn and turn < now and (not targetTurn or turn > targetTurn) then
                target, targetTurn = name, turn
            end
        end
    end
    if not target then log("No earlier snapshot is available."); return nil end
    log(command .. " -> " .. target)
    return target
end
function ITBTR_loaded(status)
    if status == "ok" then
        log("Board restored. Player turn " .. tostring(Game and Game:GetTurnCount()))
    else
        log("Native loader reported failure. See modloader.log.")
    end
end
function mod:init()
    local loader, why = package.loadlib(self.scriptPath .. "rollback_native.dll", "luaopen_rollback_native")
    if not loader then error("TurnRollback native bridge: " .. tostring(why)) end
    native = loader()
    if type(native.deleteSnapshot) ~= "function" then
        error("TurnRollback: native bridge must be updated to v1.1.0")
    end
    local ok, message = native.install()
    if not ok then error("TurnRollback: " .. tostring(message)) end
    modApi.events.onModContentReset:subscribe(function() enabled = false end)
    log("Native bridge installed for Windows Steam 1.2.93")
end
function mod:load()
    enabled = true
    modApi:addMissionStartHook(function(m)
        -- Loading a deployment snapshot can repeat deployment callbacks. Keep
        -- this battle's history intact if that happens.
        if currentHistory() then return end
        local ok, why = pcall(cleanupSnapshots)
        if not ok then log("Cleanup deferred: " .. tostring(why)) end
        local key = nextName()
        m.ITBTR_battle = key
        GAME.ITBTR = {battle = key, turns = {}, pendingStart = true, owner = mod.id}
        log("New battle: " .. key)
    end)
    modApi:addMissionEndHook(function()
        if GAME then GAME.ITBTR = nil end
    end)
    log("Ready v1.1.0: prev / restart; previous battle snapshots cleaned at new battle")
end
return mod
