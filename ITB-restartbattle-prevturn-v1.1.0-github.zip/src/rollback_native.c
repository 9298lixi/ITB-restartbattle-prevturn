/* Native console/save bridge for the Windows Steam Breach.exe 1.2.93.
 * Compiled as a 32-bit DLL without a C runtime. No files or remote processes
 * are patched. Two in-process hooks are guarded by build/signature checks.
 */
typedef unsigned int u32;
typedef unsigned char u8;
typedef void lua_State;
#define WINAPI __attribute__((stdcall))
#define THISCALL __attribute__((thiscall))
#define FASTCALL __attribute__((fastcall))
#define EXPORT __declspec(dllexport)
#define IMPORT __declspec(dllimport)
IMPORT void * WINAPI GetModuleHandleA(const char *);
IMPORT void * WINAPI GetProcAddress(void *, const char *);
IMPORT void * WINAPI VirtualAlloc(void *, u32, u32, u32);
IMPORT int WINAPI VirtualProtect(void *, u32, u32, u32 *);
IMPORT int WINAPI FlushInstructionCache(void *, const void *, u32);
IMPORT void * WINAPI GetCurrentProcess(void);

typedef struct { char buf[16]; u32 size, capacity; } MsvcString;
typedef void (THISCALL *SaveFn)(void *, MsvcString, int);
typedef int (THISCALL *LoadFn)(void *, MsvcString);
typedef void (THISCALL *DispatchFn)(void *);
typedef MsvcString *(THISCALL *StringCtor)(MsvcString *, const char *);
static SaveFn original_save;
static LoadFn game_load;
static DispatchFn original_dispatch;
static StringCtor game_string_ctor;
static void *game_delete __attribute__((used));
static lua_State *state;
static u8 *image;
static int installed, restoring, inside_save;
static const char *install_error = "bridge not installed";

static int (*l_gettop)(lua_State *);
static void (*l_settop)(lua_State *, int);
static void (*l_getfield)(lua_State *, int, const char *);
static void (*l_setfield)(lua_State *, int, const char *);
static void (*l_pushstring)(lua_State *, const char *);
static void (*l_pushboolean)(lua_State *, int);
static void (*l_pushcclosure)(lua_State *, int (*)(lua_State *), int);
static void (*l_createtable)(lua_State *, int, int);
static int (*l_pcall)(lua_State *, int, int, int);
static int (*l_type)(lua_State *, int);
static const char *(*l_tolstring)(lua_State *, int, u32 *);

static void copy(void *dst, const void *src, u32 n) {
    u8 *d = dst; const u8 *s = src; while (n--) *d++ = *s++;
}
static int equal(const char *a, const char *b) {
    while (*a && *a == *b) { ++a; ++b; } return *a == *b;
}
static int bytes_equal(const u8 *a, const u8 *b, u32 n) {
    while (n--) if (*a++ != *b++) return 0; return 1;
}
/* The game's delete helper takes a bool in CL and a by-value string on the
 * stack, with caller cleanup. It destroys that string, including its buffer. */
static void __attribute__((naked, noinline)) delete_string(MsvcString *value) {
    __asm__ volatile(
        "mov 4(%esp), %eax\n"
        "push 20(%eax)\n" "push 16(%eax)\n" "push 12(%eax)\n"
        "push 8(%eax)\n" "push 4(%eax)\n" "push 0(%eax)\n"
        "mov $1, %ecx\n" "mov _game_delete, %eax\n" "call *%eax\n"
        "add $24, %esp\n" "ret\n"
    );
}
static MsvcString short_string(const char *s) {
    MsvcString v; u32 i = 0;
    for (u32 j = 0; j < 16; ++j) v.buf[j] = 0;
    while (s[i] && i < 15) { v.buf[i] = s[i]; ++i; }
    v.size = i; v.capacity = 15; return v;
}
static const char *string_data(const MsvcString *s) {
    return s->capacity < 16 ? s->buf : *(const char *const *)s->buf;
}
/* Call a Lua callback without letting Lua errors cross the native game stack. */
static int callback(const char *name, const char *arg, char *result) {
    if (!state) return 0;
    int top = l_gettop(state), ok = 0;
    l_getfield(state, -10002, name);
    if (l_type(state, -1) == 6) {
        l_pushstring(state, arg);
        if (l_pcall(state, 1, 1, 0) == 0 && l_type(state, -1) == 4) {
            u32 n = 0; const char *s = l_tolstring(state, -1, &n);
            if (s && n > 0 && n < 16) {
                if (result) { copy(result, s, n); result[n] = 0; }
                ok = 1;
            }
        }
    }
    l_settop(state, top); return ok;
}
static void FASTCALL save_hook(void *self, void *unused, MsvcString name, int undo) {
    (void)unused;
    char snapshot[16]; int capture = 0;
    if (!inside_save && !restoring && *(u32 *)((u8 *)self + 8) == 1) {
        const char *source = string_data(&name);
        if (equal(source, "saveData.lua") || equal(source, "undoSave.lua"))
            capture = callback("ITBTR_chooseSnapshot", source, snapshot);
    }
    ++inside_save;
    original_save(self, name, undo);
    if (capture) original_save(self, short_string(snapshot), undo);
    --inside_save;
}
static void FASTCALL dispatch_hook(void *self, void *unused) {
    (void)unused;
    const MsvcString *pending = (const MsvcString *)(image + 0x4bc980);
    const char *text = string_data(pending);
    const char *cmd = 0;
    if (pending->size == 4 && equal(text, "prev")) cmd = "prev";
    if (pending->size == 7 && equal(text, "restart")) cmd = "restart";
    if (cmd && !restoring) {
        /* This is the same consumed-command flag used by the built-in parser. */
        image[0x4b9c6e] = 1;
        char target[16];
        if (callback("ITBTR_prepare", cmd, target)) {
            /* Nonstandard filenames otherwise enter the regular-load backup
             * rotation, which renames the source snapshot. During this one
             * synchronous load, take the built-in undo path past rotation. */
            u8 *branch = image + 0x209db3;
            u8 saved[6]; u32 protection;
            copy(saved, branch, 6);
            if (!VirtualProtect(branch, 6, 0x40, &protection)) {
                callback("ITBTR_loaded", "failed", 0); return;
            }
            branch[0] = 0xe9;
            *(u32 *)(branch + 1) = 0x209ea5 - (0x209db3 + 5);
            branch[5] = 0x90;
            FlushInstructionCache(GetCurrentProcess(), branch, 6);
            restoring = 1;
            int loaded = game_load(self, short_string(target));
            restoring = 0;
            copy(branch, saved, 6);
            FlushInstructionCache(GetCurrentProcess(), branch, 6);
            u32 ignored; VirtualProtect(branch, 6, protection, &ignored);
            callback("ITBTR_loaded", loaded ? "ok" : "failed", 0);
        }
        return;
    }
    original_dispatch(self);
}
/* The displaced instructions are exactly push ebp; mov ebp,esp; push -1.
 * They contain no relative operands. Both functions have the same prologue. */
static void *make_trampoline(u8 *where) {
    u8 *tr = VirtualAlloc(0, 10, 0x3000, 0x40);
    if (!tr) return 0;
    copy(tr, where, 5); tr[5] = 0xe9;
    *(u32 *)(tr + 6) = (u32)(where + 5) - (u32)(tr + 10);
    FlushInstructionCache(GetCurrentProcess(), tr, 10); return tr;
}
static void write_jump(u8 *where, void *target) {
    where[0] = 0xe9; *(u32 *)(where + 1) = (u32)target - (u32)(where + 5);
    FlushInstructionCache(GetCurrentProcess(), where, 5);
}
static int install(void) {
    if (installed) return 1;
    image = GetModuleHandleA(0);
    if (!image || *(unsigned short *)image != 0x5a4d) return 0;
    u8 *pe = image + *(u32 *)(image + 0x3c);
    if (*(u32 *)pe != 0x4550 || *(unsigned short *)(pe + 4) != 0x14c ||
        *(u32 *)(pe + 8) != 1710319986u || *(u32 *)(pe + 0x50) != 5697536u) {
        install_error = "Unsupported Breach.exe build (requires Steam Windows 1.2.93)";
        return 0;
    }
    const u8 prologue[] = {0x55,0x8b,0xec,0x6a,0xff};
    if (!bytes_equal(image + 0x20a400, prologue, 5) ||
        !bytes_equal(image + 0x20a050, prologue, 5) ||
        !bytes_equal(image + 0x209900, prologue, 5) ||
        !bytes_equal(image + 0x09e5d0, prologue, 5) ||
        !bytes_equal(image + 0x007e10, (const u8 *)"\x55\x8b\xec\x56\x8b\xf1", 6) ||
        !bytes_equal(image + 0x209db3, (const u8 *)"\x0f\x84\xec\x00\x00\x00", 6) ||
        !equal((char *)image + 0x434fc8, "undoturn")) {
        install_error = "Native function signature mismatch; no hooks installed";
        return 0;
    }
    original_dispatch = make_trampoline(image + 0x20a400);
    original_save = make_trampoline(image + 0x20a050);
    game_load = (LoadFn)(image + 0x209900);
    game_string_ctor = (StringCtor)(image + 0x007e10);
    game_delete = image + 0x09e5d0;
    if (!original_dispatch || !original_save) {
        install_error = "Could not allocate native trampolines"; return 0;
    }
    u32 first, second;
    if (!VirtualProtect(image + 0x20a400, 5, 0x40, &first)) {
        install_error = "Could not make console hook writable"; return 0;
    }
    if (!VirtualProtect(image + 0x20a050, 5, 0x40, &second)) {
        u32 ignored; VirtualProtect(image + 0x20a400, 5, first, &ignored);
        install_error = "Could not make save hook writable"; return 0;
    }
    write_jump(image + 0x20a050, save_hook);
    write_jump(image + 0x20a400, dispatch_hook);
    u32 ignored;
    VirtualProtect(image + 0x20a400, 5, first, &ignored);
    VirtualProtect(image + 0x20a050, 5, second, &ignored);
    installed = 1; install_error = "ok"; return 1;
}
static int lua_install(lua_State *L) {
    state = L; l_pushboolean(L, install()); l_pushstring(L, install_error); return 2;
}
static int lua_delete_snapshot(lua_State *L) {
    u32 length = 0;
    const char *path = l_tolstring(L, 1, &length);
    if (!installed || restoring || inside_save || !path || length < 14 || length > 32767) {
        l_pushboolean(L, 0); return 1;
    }
    const char *name = path;
    for (u32 i = 0; i < length; ++i) {
        if (!path[i]) { l_pushboolean(L, 0); return 1; }
        if (path[i] == '/' || path[i] == '\\') name = path + i + 1;
    }
    int valid = (path + length - name == 14 && name[0] == 't' && name[1] == 'r');
    for (u32 i = 2; valid && i < 10; ++i)
        valid = (name[i] >= '0' && name[i] <= '9') ||
                (name[i] >= 'a' && name[i] <= 'f') || (name[i] >= 'A' && name[i] <= 'F');
    if (!valid || !equal(name + 10, ".lua")) { l_pushboolean(L, 0); return 1; }
    MsvcString value;
    game_string_ctor(&value, path);
    delete_string(&value);
    l_pushboolean(L, 1); return 1;
}
EXPORT int luaopen_rollback_native(lua_State *L) {
    void *lua = GetModuleHandleA("lua5.1-original.dll");
    if (!lua) lua = GetModuleHandleA("lua5.1.dll");
    if (!lua) return 0;
#define RESOLVE(v,n) v = (void *)GetProcAddress(lua,n); if (!v) return 0
    RESOLVE(l_gettop,"lua_gettop"); RESOLVE(l_settop,"lua_settop");
    RESOLVE(l_getfield,"lua_getfield"); RESOLVE(l_setfield,"lua_setfield");
    RESOLVE(l_pushstring,"lua_pushstring"); RESOLVE(l_pushboolean,"lua_pushboolean");
    RESOLVE(l_pushcclosure,"lua_pushcclosure"); RESOLVE(l_createtable,"lua_createtable");
    RESOLVE(l_pcall,"lua_pcall"); RESOLVE(l_type,"lua_type");
    RESOLVE(l_tolstring,"lua_tolstring");
#undef RESOLVE
    state = L; l_createtable(L, 0, 2);
    l_pushcclosure(L, lua_install, 0); l_setfield(L, -2, "install");
    l_pushcclosure(L, lua_delete_snapshot, 0); l_setfield(L, -2, "deleteSnapshot"); return 1;
}
int WINAPI DllMain(void *module, u32 reason, void *reserved) {
    (void)module; (void)reason; (void)reserved; return 1;
}
