# Into the Breach：prev / restart

在游戏普通控制台中，输入 `prev` 回到上一个玩家回合，输入 `restart` 重开当前战斗。

## 兼容环境

- Windows Steam 版《Into the Breach》1.2.93。
- ModLoader 2.9.6。
- 当前原生 DLL 按该游戏构建适配，包含版本与函数签名检查。

## 安装

1. 先安装 [ITB ModLoader](https://github.com/itb-community/ITB-ModLoader/releases)。
2. 下载本仓库：点击 **Code → Download ZIP**，解压。
3. 把本仓库 `mods` 目录里的整个 `ITB_TurnRollback_Lua` 文件夹，放进游戏的 `mods` 目录。
4. 启动游戏，在 **Mod Content** 中启用 **Turn Rollback - prev / restart**，重启游戏。
5. 进入一场新的战斗。安装前已开始的战斗没有回合历史。

安装后的目录应为：

```text
Into the Breach/
└── mods/
    └── ITB_TurnRollback_Lua/
        └── scripts/
            ├── init.lua
            └── rollback_native.dll
```

升级时先把旧版本的这个 Mod 文件夹移到 `mods` 目录外，再放入新版本；同一 Mod ID 只保留一份。早期版本可能位于 `ITB_TurnRollback_Native_Attempt/ITB_TurnRollback_Lua`。

## 使用

在玩家回合、所有动画结束后，切换英文输入法，按键盘左上角的 **` / ~** 打开控制台。
使用普通命令模式，**不按 Tab，不加括号**。

| 命令 | 功能 |
| --- | --- |
| `prev` | 回到上一个玩家回合开头，撤销其后的敌方行动。可连续逐回合回退。 |
| `restart` | 恢复本场战斗最早的快照；通常为部署阶段，否则为首个已记录的玩家回合。 |

输入命令后按回车。第一回合没有更早的玩家回合时，`prev` 会提示没有可用快照。
重新加载当前存档时，可以继续使用随存档保留的本场历史。

## 快照清理

v1.1.0 在进入下一场新战斗时，自动清理当前玩家档案内的旧战斗快照，包括 v1.0 积累的快照。
当前战斗的快照保留；继续游戏和 `restart` 不触发清理。
清理只处理文件名和内容均确认属于本 Mod 的 `trXXXXXXXX.lua` 文件，不处理其他玩家档案和游戏普通存档。
同一场战斗的分支快照会保留到下一场战斗开始。清理失败会记录日志，下场战斗再重试。

## 排查问题

查看游戏目录的 `modloader.log`，搜索 `[TurnRollback]`：

- `Ready v1.1.0`：Mod 已加载。
- `snapshot`：已保存快照。
- `Board restored`：原生加载入口报告恢复成功。
- `Old snapshots cleaned`：已清理旧快照，`failed` 表示失败数量。
- `No history for this battle`：请进入一场新战斗。

## 源码与测试

- `mods/ITB_TurnRollback_Lua/scripts/init.lua`：命令逻辑、回合历史、旧快照清理。
- `src/rollback_native.c`：32 位 Windows 原生桥接源码。
- `rollback_native.dll`：预编译原生桥接，无需玩家自行编译。

通过游戏的原生保存/加载流程恢复棋盘；原生钩子仅作用于游戏进程，不修改游戏 EXE 或 ModLoader DLL 文件。

回退和重开已有游戏内验证。v1.1 自动清理已通过 Lua 5.1 逻辑及独立 32 位原生接口测试，仍需更多真实游戏验证。

## 卸载

退出游戏，把 `ITB_TurnRollback_Lua` 文件夹移出 `mods`，再重新打开游戏。
